# GO Benchmarking
This is a simple package for generating Gene Ontology datasets from the SwissProt and GOA databases. It contains files for downloading and processing all data to generate training, validation, and testing sets. 

